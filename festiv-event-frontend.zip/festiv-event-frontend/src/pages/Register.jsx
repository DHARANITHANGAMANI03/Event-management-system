import { useState } from "react";
import { useSearchParams } from "react-router-dom";

const Register = () => {
  const [form, setForm] = useState({ name: "", email: "", phone: "",college: "", city: "", address: "" });
  const [searchParams] = useSearchParams();
  const eventId = searchParams.get("eventId");

  const handleChange = (e) => {
    setForm({ ...form, [e.target.name]: e.target.value });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    const response = await fetch("http://localhost:5000/api/bookings", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ ...form, eventId }),
    });

    if (response.ok) {
      alert("Registration successful! Check your email for ticket details.");
      setForm({ name: "", email: "", phone: "", college:"", city: "", address: "" });
    }
  };

  return (
    <div className="min-h-screen bg-black text-white p-6 flex justify-center">
      <form onSubmit={handleSubmit} className="bg-gray-900 p-8 rounded-lg shadow-lg w-96">
        <h2 className="text-xl font-bold mb-4">Register for Event</h2>
        <input name="name" placeholder="Name" onChange={handleChange} className="w-full p-2 mb-3 bg-gray-800 border border-gray-700 rounded" />
        <input name="email" placeholder="Email" onChange={handleChange} className="w-full p-2 mb-3 bg-gray-800 border border-gray-700 rounded" />
        <input name="phone" placeholder="Phone" onChange={handleChange} className="w-full p-2 mb-3 bg-gray-800 border border-gray-700 rounded" />
        <input name="college" placeholder="College" onChange={handleChange} className="w-full p-2 mb-3 bg-gray-800 border border-gray-700 rounded" />
        <input name="city" placeholder="City" onChange={handleChange} className="w-full p-2 mb-3 bg-gray-800 border border-gray-700 rounded" />
        <input name="address" placeholder="Address" onChange={handleChange} className="w-full p-2 mb-3 bg-gray-800 border border-gray-700 rounded" />
        <button type="submit" className="w-full bg-blue-700 hover:bg-blue-500 text-white p-2 rounded">Register</button>
      </form>
    </div>
  );
};

export default Register;
