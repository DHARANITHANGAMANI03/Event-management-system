import { Link } from "react-router-dom";

const Header = () => {
  return (
    <header className="bg-black text-white p-4 flex justify-between items-center">
      <h1 className="text-xl font-bold">Colletalk</h1>
      <nav>
        <Link to="/" className="mr-4 text-blue-500">Home</Link>
        <Link to="/register" className="text-blue-500">Register</Link>
      </nav>
    </header>
  );
};

export default Header;
