const Booking = require("../models/bookingModel");
const nodemailer = require("nodemailer");
const crypto = require("crypto");

exports.bookEvent = async (req, res) => {
  const ticketId = crypto.randomBytes(5).toString("hex"); // Generate Unique Ticket ID

  const newBooking = new Booking({ ...req.body, ticketId });
  await newBooking.save();

  // Send Email with Ticket ID
  const transporter = nodemailer.createTransport({
    service: "Gmail",
    auth: {
      user: process.env.EMAIL,
      pass: process.env.EMAIL_PASS,
    },
  });

  const mailOptions = {
    from: process.env.EMAIL,
    to: req.body.email,
    subject: "Your Event Ticket",
    html: `<h3>Thank you for booking!</h3>
           <p>Your Ticket ID: <b>${ticketId}</b></p>`,
  };

  transporter.sendMail(mailOptions);

  res.json({ message: "Booking Successful! Check your email for ticket details." });
};
