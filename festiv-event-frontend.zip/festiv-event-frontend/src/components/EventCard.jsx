const EventCard = ({ event, onRegister }) => {
  return (
    <div className="bg-gray-900 text-white p-5 rounded-lg shadow-lg">
      <img
        src={`http://localhost:5000${event.image}`}
        alt={event.title}
        className="w-full h-40 object-cover rounded-md"
      />
      <h2 className="text-lg font-bold mt-3">{event.title}</h2>
      <p>{event.college}</p>
      <p className="text-sm text-gray-400">
        {event.date} - {event.location}
      </p>
      <p>{event.description}</p>

      <button
        onClick={() => onRegister(event._id)}
        className="bg-blue-700 hover:bg-blue-500 text-white px-4 py-2 rounded mt-3 w-full"
      >
        Register
      </button>
    </div>
  );
};

export default EventCard;
