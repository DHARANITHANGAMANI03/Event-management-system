const Footer = () => {
    return (
      <footer className="bg-black text-white text-center p-4 mt-5">
        <p>&copy; 2024 Colletalk. All Rights Reserved.</p>
      </footer>
    );
  };
  
  export default Footer;
  