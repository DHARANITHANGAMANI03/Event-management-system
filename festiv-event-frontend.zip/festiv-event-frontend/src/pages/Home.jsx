// import { useState, useEffect } from "react";
// import EventCard from "../components/EventCard";
// import { useNavigate } from "react-router-dom";

// const Home = () => {
//   const [events, setEvents] = useState([]);
//   const navigate = useNavigate();

//   useEffect(() => {
//     fetch("http://localhost:5000/api/events")
//       .then((res) => res.json())
//       .then((data) => setEvents(data));
//   }, []);

//   const handleRegister = (eventId) => {
//     navigate(`/register?eventId=${eventId}`);
//   };

//   return (
//     <>
//       {/* GIF Banner Section */}
//       <div className="flex justify-center">
//         <img
//           src="https://dubainight.com/_next/image?url=https%3A%2F%2Fapi.dubainight.com%2Fstatic-image%2Fregion_dubai%2Fmisc%2FSky2.0Medi-3331-2022-10-12.gif&w=3840&q=75"
//           alt="FestivEvent GIF"
//           className="w-full max-h-[400px] object-cover"
//         />
//       </div>
//        {/* Upcoming Events Section */}
//       <div className="min-h-screen bg-black text-white p-6">
//         <h1 className="text-3xl font-bold mb-6">Upcoming Events</h1>
//         <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-6">
//           {events.map((event) => (
//             <EventCard
//               key={event._id}
//               event={event}
//               onRegister={handleRegister}
//             />
//           ))}
//         </div>
//       </div>
//     </>
//   );
// };

// export default Home;
import { useState, useEffect } from "react";
import EventCard from "../components/EventCard";
import { useNavigate } from "react-router-dom";

const Home = () => {
  const [events, setEvents] = useState([]);
  const [searchTerm, setSearchTerm] = useState(""); // 🔍 Search State
  const navigate = useNavigate();

 const fetchEvents = async () => {
    const query = searchTerm ? `?title=${searchTerm}` : "";
    const res = await fetch(`http://localhost:5000/api/events${query}`);
    const data = await res.json();
    setEvents(data);
  };

  useEffect(() => {
    fetchEvents();
  }, [searchTerm]); // 🔄 Fetch on search change
  
  const handleRegister = (eventId) => {
    navigate(`/register?eventId=${eventId}`);
  };

  return (
    <>
      {/* GIF Banner Section */}
      <div className="flex justify-center">
        <img
          src="https://dubainight.com/_next/image?url=https%3A%2F%2Fapi.dubainight.com%2Fstatic-image%2Fregion_dubai%2Fmisc%2FSky2.0Medi-3331-2022-10-12.gif&w=3840&q=75"
          alt="FestivEvent GIF"
          className="w-full max-h-[400px] object-cover"
        />
      </div>

      {/* Upcoming Events Section with Search */}
      <div className="min-h-screen bg-black text-white p-6">
        <div className="flex justify-between items-center mb-6">
          <h1 className="text-3xl font-bold">Upcoming Events</h1>

          {/* 🔍 Search Input */}
          <input
            type="text"
            placeholder="Search events..."
            className="p-2 rounded bg-gray-800 text-white border border-gray-600"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
          />
        </div>

        {/* Events Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-6">
          {events.length > 0 ? (
            events.map((event) => (
              <EventCard key={event._id} event={event} onRegister={handleRegister} />
            ))
          ) : (
            <p className="text-gray-400">No events found</p>
          )}
        </div>
      </div>
    </>
  );
};

export default Home;
