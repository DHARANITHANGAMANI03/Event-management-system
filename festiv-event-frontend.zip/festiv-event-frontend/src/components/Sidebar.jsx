import { Link } from "react-router-dom";

const Sidebar = () => {
  return (
    <aside className="bg-gray-900 text-white w-64 min-h-screen p-5">
      <h2 className="text-xl font-bold mb-4">Admin Panel</h2>
      <nav>
        <Link to="/admin/events" className="block p-2 mb-2 bg-blue-700 rounded">
          Event List
        </Link>
        <Link to="/admin/add-event" className="block p-2 bg-blue-700 rounded">
          Add Event
        </Link>
      </nav>
    </aside>
  );
};

export default Sidebar;
