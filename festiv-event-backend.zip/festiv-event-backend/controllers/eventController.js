const Event = require("../models/eventModel");
const multer = require("multer");
const path = require("path");
// exports.getEvents = async (req, res) => {
//   const events = await Event.find();
//   res.json(events);
// };
// http://localhost:5000/api/events?title=helo

exports.getEvents = async (req, res) => {
  try {
    const { title } = req.query;
    let query = {};

    if (title) {
      query.title = { $regex: title, $options: "i" }; // Case-insensitive search
    }

    const events = await Event.find(query);
    res.json(events);
  } catch (error) {
    res.status(500).json({ message: "Server Error", error });
  }
};

// exports.createEvent = async (req, res) => {
//   const newEvent = new Event(req.body);
//   await newEvent.save();
//   res.json({ message: "Event Created Successfully!" });
// };

exports.updateEvent = async (req, res) => {
  await Event.findByIdAndUpdate(req.params.id, req.body);
  res.json({ message: "Event Updated Successfully!" });
};

exports.deleteEvent = async (req, res) => {
  await Event.findByIdAndDelete(req.params.id);
  res.json({ message: "Event Deleted Successfully!" });
};

// --------------

// Configure Multer Storage
const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    cb(null, "uploads/"); // Save in uploads folder
  },
  filename: (req, file, cb) => {
    cb(null, Date.now() + path.extname(file.originalname)); // Unique filename
  },
});

// File Filter (Only images allowed)
const fileFilter = (req, file, cb) => {
  if (file.mimetype.startsWith("image/")) {
    cb(null, true);
  } else {
    cb(new Error("Only images are allowed!"), false);
  }
};

// Upload Middleware
const upload = multer({ storage, fileFilter });

// Create Event with Image Upload
exports.createEvent = async (req, res) => {
  try {
    const { title, college, date, location, description } = req.body;
    const imageUrl = req.file ? `/uploads/${req.file.filename}` : "";

    const newEvent = new Event({
      title,
      college,
      date,
      location,
      description,
      image: imageUrl,
    });

    await newEvent.save();
    res.json({ message: "Event Created Successfully!", event: newEvent });
  } catch (error) {
    res.status(500).json({ message: "Server Error", error });
  }
};

module.exports.upload = upload;