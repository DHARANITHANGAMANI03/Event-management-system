const mongoose = require("mongoose");

const bookingSchema = new mongoose.Schema({
  name: String,
  email: String,
  phone: String,
  college: String,
  city: String,
  address: String,
  eventId: String,
  ticketId: String,
});

module.exports = mongoose.model("Booking", bookingSchema);
