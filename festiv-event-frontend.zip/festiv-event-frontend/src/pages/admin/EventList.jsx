import { useState, useEffect } from "react";

const EventList = () => {
  const [events, setEvents] = useState([]);
  const [editingEvent, setEditingEvent] = useState(null); // For Edit Modal
  const [formData, setFormData] = useState({
    title: "",
    college: "",
    date: "",
    location: "",
    // description:"",
    // image:""
  });

  useEffect(() => {
    fetchEvents();
  }, []);

  const fetchEvents = async () => {
    const res = await fetch("http://localhost:5000/api/events");
    const data = await res.json();
    setEvents(data);
  };

  // Open Edit Modal
  const handleEdit = (event) => {
    setEditingEvent(event);
    setFormData({
      title: event.title,
      college: event.college,
      date: event.date,
      location: event.location,
    });
  };

  // Handle Form Change
  const handleChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  // Update Event
  const handleUpdate = async () => {
    const res = await fetch(
      `http://localhost:5000/api/events/${editingEvent._id}`,
      {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(formData),
      }
    );

    if (res.ok) {
      fetchEvents(); // Refresh List
      setEditingEvent(null); // Close Modal
    }
  };

  // Delete Event
  const handleDelete = async (id) => {
    if (window.confirm("Are you sure you want to delete this event?")) {
      await fetch(`http://localhost:5000/api/events/${id}`, {
        method: "DELETE",
      });
      fetchEvents(); // Refresh List
    }
  };

  return (
    <div>
      <h2 className="text-2xl font-bold mb-4">Event List</h2>
      <table className="w-full border border-gray-700">
        <thead>
          <tr className="bg-gray-800">
            <th className="border p-2">Image</th>
            <th className="border p-2">Event Title</th>
            <th className="border p-2">College name</th>
            <th className="border p-2">Date Of Event</th>
            <th className="border p-2">Location</th>
            <th className="border p-2">Description</th>
            <th className="border p-2">Actions</th>
          </tr>
        </thead>
        <tbody>
          {events.map((event) => (
            <tr
              key={event._id}
              className="text-center border-t border-gray-700"
            >
              <td className="p-2">
                <img
                  src={`http://localhost:5000${event.image}`}
                  alt="event thumb"
                  width={50}
                  height={50}
                />
              </td>
              <td className="p-2">{event.title}</td>
              <td className="p-2">{event.college}</td>
              <td className="p-2">{event.date}</td>
              <td className="p-2">{event.location}</td>
              <td className="p-2">{event.description}</td>
              <td className="p-2">
                <button
                  onClick={() => handleEdit(event)}
                  className="bg-blue-700 p-1 rounded mr-2"
                >
                  Edit
                </button>
                <button
                  onClick={() => handleDelete(event._id)}
                  className="bg-red-700 p-1 rounded"
                >
                  Delete
                </button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>

      {/* Edit Modal */}
      {editingEvent && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex justify-center items-center">
          <div className="bg-gray-900 p-6 rounded-lg w-96">
            <h3 className="text-xl font-bold mb-4">Edit Event</h3>
            <input
              type="text"
              name="title"
              value={formData.title}
              onChange={handleChange}
              className="w-full p-2 mb-2 border border-gray-700 rounded bg-black text-white"
              placeholder="Event Title"
            />
            <input
              type="text"
              name="college"
              value={formData.college}
              onChange={handleChange}
              className="w-full p-2 mb-2 border border-gray-700 rounded bg-black text-white"
              placeholder="College"
            />
            <input
              type="date"
              name="date"
              value={formData.date}
              onChange={handleChange}
              className="w-full p-2 mb-2 border border-gray-700 rounded bg-black text-white"
            />
            <input
              type="text"
              name="location"
              value={formData.location}
              onChange={handleChange}
              className="w-full p-2 mb-4 border border-gray-700 rounded bg-black text-white"
              placeholder="Location"
            />
            <button
              onClick={handleUpdate}
              className="bg-blue-700 p-2 rounded w-full"
            >
              Update
            </button>
            <button
              onClick={() => setEditingEvent(null)}
              className="mt-2 text-gray-400 w-full"
            >
              Cancel
            </button>
          </div>
        </div>
      )}
    </div>
  );
};

export default EventList;
