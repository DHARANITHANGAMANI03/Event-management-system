const express = require("express");
const {
  getEvents,
  createEvent,
  updateEvent,
  deleteEvent,
  upload
} = require("../controllers/eventController");

const router = express.Router();

router.get("/", getEvents);
// router.post("/", createEvent);
router.post("/", upload.single("image"), createEvent); // Image Upload
router.put("/:id", updateEvent);
router.delete("/:id", deleteEvent);

module.exports = router;
