// import { useState } from "react";

// const AddEvent = () => {
//   const [form, setForm] = useState({ title: "", college:"", date: "", location: "", description: "", image: "" });

//   const handleChange = (e) => {
//     setForm({ ...form, [e.target.name]: e.target.value });
//   };

//   const handleSubmit = async (e) => {
//     e.preventDefault();
//     const response = await fetch("http://localhost:5000/api/events", {
//       method: "POST",
//       headers: { "Content-Type": "application/json" },
//       body: JSON.stringify(form),
//     });

//     if (response.ok) {
//       alert("Event added successfully!");
//       setForm({ title: "", college:"", date: "", location: "", description: "", image: "" });
//     }
//   };

//   return (
//     <div>
//       <h2 className="text-2xl font-bold mb-4">Add New Event</h2>
//       <form onSubmit={handleSubmit} className="bg-gray-900 p-6 rounded-lg">
//         <input name="title" placeholder="Event Title" value={form.title} onChange={handleChange} className="w-full p-2 mb-3 bg-gray-800 border border-gray-700 rounded" />
//         <input name="college" placeholder="College name" value={form.college} onChange={handleChange} className="w-full p-2 mb-3 bg-gray-800 border border-gray-700 rounded" />
//         <input type="date" name="date" value={form.date} onChange={handleChange} className="w-full p-2 mb-3 bg-gray-800 border border-gray-700 rounded" />
//         <input name="location" placeholder="Location" value={form.location} onChange={handleChange} className="w-full p-2 mb-3 bg-gray-800 border border-gray-700 rounded" />
//         <textarea name="description" placeholder="Description" value={form.description} onChange={handleChange} className="w-full p-2 mb-3 bg-gray-800 border border-gray-700 rounded"></textarea>
//         <input name="image" placeholder="Image URL" value={form.image} onChange={handleChange} className="w-full p-2 mb-3 bg-gray-800 border border-gray-700 rounded" />
//         <button type="submit" className="bg-blue-700 p-2 w-full rounded">Add Event</button>
//       </form>
//     </div>
//   );
// };

// export default AddEvent;

import { useState } from "react";

const AddEvent = () => {
  const [form, setForm] = useState({
    title: "",
    college: "",
    date: "",
    location: "",
    description: "",
  });
  const [image, setImage] = useState(null);

  const handleChange = (e) => {
    setForm({ ...form, [e.target.name]: e.target.value });
  };

  const handleImageChange = (e) => {
    setImage(e.target.files[0]); // Store file
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    const formData = new FormData();
    
    // Append text fields
    Object.keys(form).forEach((key) => {
      formData.append(key, form[key]);
    });

    // Append file if selected
    if (image) {
      formData.append("image", image);
    }

    const response = await fetch("http://localhost:5000/api/events", {
      method: "POST",
      body: formData,
    });

    if (response.ok) {
      alert("Event added successfully!");
      setForm({ title: "", college: "", date: "", location: "", description: "" });
      setImage(null);
    }
  };

  return (
    <div>
      <h2 className="text-2xl font-bold mb-4">Add New Event</h2>
      <form onSubmit={handleSubmit} className="bg-gray-900 p-6 rounded-lg">
        <input name="title" placeholder="Event Title" value={form.title} onChange={handleChange} className="w-full p-2 mb-3 bg-gray-800 border border-gray-700 rounded" />
        <input name="college" placeholder="College name" value={form.college} onChange={handleChange} className="w-full p-2 mb-3 bg-gray-800 border border-gray-700 rounded" />
        <input type="date" name="date" value={form.date} onChange={handleChange} className="w-full p-2 mb-3 bg-gray-800 border border-gray-700 rounded" />
        <input name="location" placeholder="Location" value={form.location} onChange={handleChange} className="w-full p-2 mb-3 bg-gray-800 border border-gray-700 rounded" />
        <textarea name="description" placeholder="Description" value={form.description} onChange={handleChange} className="w-full p-2 mb-3 bg-gray-800 border border-gray-700 rounded"></textarea>

        {/* Image Upload Field */}
        <input type="file" accept="image/*" onChange={handleImageChange} className="w-full p-2 mb-3 bg-gray-800 border border-gray-700 rounded" />

        <button type="submit" className="bg-blue-700 p-2 w-full rounded">Add Event</button>
      </form>
    </div>
  );
};

export default AddEvent;
